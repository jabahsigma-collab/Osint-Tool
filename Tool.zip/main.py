import os
import re
import json
import random
import ipaddress
import uuid
from urllib.parse import urlsplit, quote_plus
import requests
import xml.etree.ElementTree as ET
from datetime import datetime
from flask import Flask, request, jsonify, render_template, Response

# ==============================
# OSINT — API SETTINGS
# Paste your VirusTotal key here, or set VIRUSTOTAL_API_KEY in the environment.
# Keep this key private; do not commit it to public repositories.
# ==============================
VT_API_KEY = os.getenv("VIRUSTOTAL_API_KEY", "411bb1424aa0c50184ae08d870aa9bf42e627c5a5b43f0c576f4c99ad41fe8d8").strip()
VT_BASE_URL = "https://www.virustotal.com/api/v3"
HISTORY_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "osint_history.json")
MAX_HISTORY_ITEMS = 50

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, template_folder=BASE_DIR, static_folder=BASE_DIR)

# Отключаем кэширование в браузере телефона, чтобы изменения применялись мгновенно
@app.after_request
def add_header(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/119.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
]

def get_random_agent():
    return random.choice(USER_AGENTS)

def check_github(username):
    url = f"https://api.github.com/users/{username}"
    headers = {"User-Agent": get_random_agent()}
    details = {"display_name": "Not found", "bio": "Not found", "created_at": "Not found"}
    try:
        r = requests.get(url, headers=headers, timeout=5)
        if r.status_code == 200:
            data = r.json()
            details["display_name"] = data.get("name") or username
            details["bio"] = data.get("bio") or "None"
            details["created_at"] = data.get("created_at", "Not found")
            return True, f"https://github.com/{username}", details
    except Exception:
        pass
    return False, f"https://github.com/{username}", details

def check_steam(username):
    url_xml = f"https://steamcommunity.com/id/{username}/?xml=1"
    url_web = f"https://steamcommunity.com/id/{username}"
    headers = {"User-Agent": get_random_agent()}
    details = {"display_name": "Not found", "bio": "Not found", "created_at": "Not found"}
    try:
        r = requests.get(url_xml, headers=headers, timeout=5)
        if r.status_code == 200 and "<profile>" in r.text and "<error>" not in r.text:
            root = ET.fromstring(r.text)
            details["display_name"] = root.findtext("steamID", username)
            details["bio"] = root.findtext("summary", "None")
            details["created_at"] = root.findtext("memberSince", "Not specified")
            return True, url_web, details
    except Exception:
        pass
    return False, url_web, details

def check_virustotal(username):
    """Check VirusTotal via its official API when configured.

    VirusTotal does not provide a reliable unauthenticated public-profile
    existence check. The API may also restrict looking up other users, so
    authorization/ratelimit failures are reported as unknown, not absent.
    Configure VIRUSTOTAL_API_KEY in the server environment.
    """
    url = f"https://www.virustotal.com/gui/user/{username}"
    api_key = VT_API_KEY if VT_API_KEY != "PASTE_VIRUSTOTAL_API_KEY_HERE" else ""
    details = {"display_name": username, "bio": "", "created_at": "Not verified"}
    if not api_key:
        details["bio"] = "Не проверено: задайте VIRUSTOTAL_API_KEY на сервере; без API-ключа нельзя достоверно подтвердить существование профиля."
        return None, url, details

    try:
        response = requests.get(
            f"https://www.virustotal.com/api/v3/users/{username}",
            headers={"x-apikey": api_key, "accept": "application/json", "User-Agent": get_random_agent()},
            timeout=8,
        )
        if response.status_code == 200:
            data = response.json().get("data", {})
            attrs = data.get("attributes", {})
            details["display_name"] = data.get("id") or username
            details["bio"] = attrs.get("profile_phrase") or "Профиль подтверждён официальным API VirusTotal"
            if attrs.get("user_since"):
                details["created_at"] = datetime.utcfromtimestamp(attrs["user_since"]).strftime("%Y-%m-%d")
            return True, url, details
        if response.status_code == 404:
            details["bio"] = "API VirusTotal вернул 404 для этого профиля"
            return False, url, details
        if response.status_code in (401, 403):
            details["bio"] = "Проверка не разрешена API VirusTotal (ключ, права или доступ к чужому профилю); существование не подтверждено"
            return None, url, details
        if response.status_code == 429:
            details["bio"] = "Лимит запросов VirusTotal исчерпан; статус профиля неизвестен"
            return None, url, details
        details["bio"] = f"VirusTotal API вернул HTTP {response.status_code}; статус профиля неизвестен"
    except (requests.RequestException, ValueError) as exc:
        details["bio"] = "Не удалось связаться с API VirusTotal; статус профиля неизвестен"
    return None, url, details

def check_telegram(username):
    url = f"https://t.me/{username}"
    headers = {"User-Agent": get_random_agent()}
    details = {"display_name": username, "bio": "Telegram Profile", "created_at": "Not specified"}
    try:
        r = requests.get(url, headers=headers, timeout=5)
        if r.status_code == 200 and "tgme_page_extra" in r.text:
            if "if you have Telegram" not in r.text and "Fast and secure" not in r.text:
                return True, url, details
    except Exception:
        pass
    return False, url, details

def check_tiktok(username):
    url = f"https://www.tiktok.com/@{username}"
    headers = {"User-Agent": get_random_agent()}
    details = {"display_name": username, "bio": "TikTok Profile", "created_at": "Not specified"}
    try:
        r = requests.get(url, headers=headers, timeout=5)
        if r.status_code == 200 and "is-banned" not in r.text:
            return True, url, details
    except Exception:
        pass
    return False, url, details

def check_youtube(username):
    url = f"https://www.youtube.com/@{username}"
    headers = {"User-Agent": get_random_agent()}
    details = {"display_name": username, "bio": "YouTube Channel", "created_at": "Not specified"}
    try:
        r = requests.get(url, headers=headers, timeout=5)
        if r.status_code == 200 and "unavailable" not in r.text.lower():
            return True, url, details
    except Exception:
        pass
    return False, url, details

def check_twitter(username):
    url = f"https://twitter.com/{username}"
    headers = {"User-Agent": get_random_agent()}
    details = {"display_name": username, "bio": "Twitter Profile", "created_at": "Not specified"}
    try:
        r = requests.get(url, headers=headers, timeout=5)
        if r.status_code == 200:
            return True, url, details
    except Exception:
        pass
    return False, url, details

def check_instagram(username):
    url = f"https://www.instagram.com/{username}/"
    headers = {"User-Agent": get_random_agent()}
    details = {"display_name": username, "bio": "Instagram Profile", "created_at": "Not specified"}
    try:
        r = requests.get(url, headers=headers, timeout=5)
        if r.status_code == 200:
            return True, url, details
    except Exception:
        pass
    return False, url, details

def check_reddit(username):
    url = f"https://www.reddit.com/user/{username}/about.json"
    headers = {"User-Agent": get_random_agent()}
    details = {"display_name": username, "bio": "Reddit Profile", "created_at": "Not found"}
    try:
        r = requests.get(url, headers=headers, timeout=5)
        if r.status_code == 200:
            d = r.json().get("data", {})
            sub = d.get("subreddit", {})
            details["display_name"] = sub.get("title", username)
            details["bio"] = sub.get("public_description", "None")
            created_utc = d.get("created_utc")
            if created_utc:
                details["created_at"] = datetime.utcfromtimestamp(created_utc).strftime('%Y-%m-%d')
            return True, f"https://www.reddit.com/user/{username}", details
    except Exception:
        pass
    return False, f"https://www.reddit.com/user/{username}", details

def check_twitch(username):
    url = f"https://www.twitch.tv/{username}"
    headers = {"User-Agent": get_random_agent()}
    details = {"display_name": username, "bio": "Twitch Channel", "created_at": "Not specified"}
    try:
        r = requests.get(url, headers=headers, timeout=5)
        if r.status_code == 200:
            return True, url, details
    except Exception:
        pass
    return False, url, details

def check_pinterest(username):
    url = f"https://www.pinterest.com/{username}/"
    headers = {"User-Agent": get_random_agent()}
    details = {"display_name": username, "bio": "Pinterest Profile", "created_at": "Not specified"}
    try:
        r = requests.get(url, headers=headers, timeout=5)
        if r.status_code == 200:
            return True, url, details
    except Exception:
        pass
    return False, url, details

def check_marketplace_search(username, platform, domain):
    """Create a public web-search link for marketplace listings.

    Marketplace pages do not expose a stable public username lookup API, so
    this intentionally returns UNKNOWN rather than guessing that an account
    exists or does not exist. The user can open indexed public results.
    """
    query = quote_plus(f'site:{domain} "{username}"')
    url = f"https://www.google.com/search?q={query}"
    details = {
        "display_name": username,
        "bio": "Public indexed search link. Results are not automatically verified.",
        "created_at": "Not verified"
    }
    return None, url, details

def check_funpay(username):
    return check_marketplace_search(username, "FunPay", "funpay.com")

def check_playerok(username):
    return check_marketplace_search(username, "Playerok", "playerok.com")

def scan_username_all(username):
    checkers = {
        "GitHub": check_github,
        "Steam": check_steam,
        "VirusTotal": check_virustotal,
        "Telegram": check_telegram,
        "TikTok": check_tiktok,
        "YouTube": check_youtube,
        "Twitter/X": check_twitter,
        "Instagram": check_instagram,
        "Reddit": check_reddit,
        "Twitch": check_twitch,
        "Pinterest": check_pinterest,
        "FunPay": check_funpay,
        "Playerok": check_playerok
    }
    
    nodes_json = [{"id": username, "group": "root", "status": True, "name": "Target User", "bio": f"Searching OSINT for @{username}", "date": "-", "url": "#", "platform": "root"}]
    links_json = []
    results_cards = []
    
    for platform, func in checkers.items():
        status_bool, url, det = func(username)
        
        nodes_json.append({
            "id": platform,
            "group": "platform",
            "status": status_bool,
            "name": det.get('display_name'),
            "bio": det.get('bio'),
            "date": det.get('created_at'),
            "url": url,
            "platform": platform
        })
        links_json.append({"source": username, "target": platform})
        
        if status_bool:
            bio_text = det.get('bio')
            if bio_text and bio_text not in ["None", "Not found"]:
                nodes_json.append({
                    "id": f"{platform}_bio",
                    "group": "info",
                    "text": f"Bio: {bio_text}",
                    "platform": platform
                })
                links_json.append({"source": platform, "target": f"{platform}_bio"})
                
            date_text = det.get('created_at')
            if date_text and date_text not in ["Not specified", "Not found"]:
                nodes_json.append({
                    "id": f"{platform}_date",
                    "group": "info",
                    "text": f"Registered: {date_text}",
                    "platform": platform
                })
                links_json.append({"source": platform, "target": f"{platform}_date"})

        results_cards.append({
            "platform": platform,
            "status": status_bool,
            "url": url,
            "name": det.get('display_name'),
            "bio": det.get('bio'),
            "date": det.get('created_at')
        })

    # Add only explicitly published external URLs/domains from public profile bios.
    # These are observed references, not proof that two accounts belong to the same person.
    known_ids = {str(node.get("id")) for node in nodes_json}
    known_domains = {}
    for card in results_cards:
        if card.get("status") is not True or not card.get("bio"):
            continue
        for found_url in re.findall(r"https?://[^\s<>\"']+", str(card["bio"])):
            clean_url = found_url.rstrip(".,);]}")
            try:
                host = (urlsplit(clean_url).hostname or "").lower()
            except ValueError:
                host = ""
            if not host:
                continue
            domain_id = "domain:" + host
            if domain_id not in known_domains:
                known_domains[domain_id] = clean_url
                nodes_json.append({"id": domain_id, "group": "info", "name": host, "text": "Public URL mentioned in profile bio", "url": clean_url, "platform": "Observed domain", "status": None})
            source_id = card["platform"]
            if not any(str(link.get("source")) == source_id and str(link.get("target")) == domain_id for link in links_json):
                links_json.append({"source": source_id, "target": domain_id, "kind": "public-bio-link"})

    txt_report = f"=== OSINT REPORT FOR USERNAME: {username} ===\nGenerated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
    for r in results_cards:
        txt_report += f"Platform: {r['platform']}\nStatus: {'FOUND' if r['status'] is True else ('NOT FOUND' if r['status'] is False else 'UNKNOWN / NOT VERIFIED')}\nURL: {r['url']}\nName: {r['name']}\nBio: {r['bio']}\nDate: {r['date']}\n----------------------------------------\n"

    return {
        "type": "username",
        "target": username,
        "nodes": nodes_json,
        "links": links_json,
        "cards": results_cards,
        "txt_report": txt_report
    }

def scan_phone_all(phone_raw):
    """Search publicly indexed pages; never fabricate phone reputation or identity."""
    phone = re.sub(r"[\s().-]", "", str(phone_raw or "")).strip()
    if not re.fullmatch(r"\+?[0-9]{7,15}", phone):
        raise ValueError("Введите номер в международном формате, например +994501234567.")
    digits = phone.lstrip("+")
    hints = [("994", "Azerbaijan", "+994"), ("380", "Ukraine", "+380"), ("1", "United States / Canada", "+1"), ("7", "Russia / Kazakhstan", "+7"), ("44", "United Kingdom", "+44"), ("49", "Germany", "+49"), ("90", "Turkey", "+90"), ("91", "India", "+91")]
    country, code = "Unknown", "Unknown"
    for prefix, label, dial in sorted(hints, key=lambda x: len(x[0]), reverse=True):
        if digits.startswith(prefix):
            country, code = label, dial
            break
    queries = [f'"{phone}"', f'"{digits}" phone', f'"{phone}" spam OR scam']
    results = []
    try:
        from bs4 import BeautifulSoup
    except ImportError:
        BeautifulSoup = None
    if BeautifulSoup:
        for query in queries:
            try:
                response = requests.get("https://html.duckduckgo.com/html/", params={"q": query}, headers={"User-Agent": "Mozilla/5.0"}, timeout=8)
                if response.ok:
                    soup = BeautifulSoup(response.text, "html.parser")
                    for item in soup.select(".result"):
                        link = item.select_one(".result__a")
                        snippet = item.select_one(".result__snippet")
                        if not link: continue
                        href = link.get("href", "")
                        if href.startswith("http") and not any(x["url"] == href for x in results):
                            results.append({"title": link.get_text(" ", strip=True), "url": href, "snippet": snippet.get_text(" ", strip=True) if snippet else "", "query": query})
            except requests.RequestException:
                continue
    search_links = [{"site": "Google", "url": "https://www.google.com/search?q=" + requests.utils.quote(f'"{phone}"')}, {"site": "Bing", "url": "https://www.bing.com/search?q=" + requests.utils.quote(f'"{phone}"')}, {"site": "DuckDuckGo", "url": "https://duckduckgo.com/?q=" + requests.utils.quote(f'"{phone}"')}, {"site": "Truecaller", "url": "https://www.truecaller.com/search"}]
    geo = {"phone": phone, "valid": True, "country": country, "code": code, "region": "Not available from number alone", "city": "Not available from number alone", "carrier": "Not verified", "note": "Country hint is based only on the dialing prefix; results may be incomplete."}
    nodes = [{"id": phone, "group": "root", "status": True, "name": f"Phone: {phone}", "bio": "Public web search", "date": "-", "url": "#", "platform": "root"}]
    links, cards = [], []
    for i, item in enumerate(results):
        nid = f"result_{i}"
        nodes.append({"id": nid, "group": "platform", "status": True, "name": item["title"][:100], "bio": item["snippet"], "date": "-", "url": item["url"], "platform": "Public web result"})
        links.append({"source": phone, "target": nid}); cards.append(item)
    report = f"PUBLIC WEB SEARCH REPORT FOR PHONE: {phone}\nGenerated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\nCountry-code hint: {country} ({code})\nPrecise owner, city, carrier and reputation are not inferred or fabricated.\n\n"
    report += "\n\n".join(f"{x['title']}\n{x['url']}\n{x['snippet']}" for x in cards) if cards else "No indexed results retrieved automatically. Use search-engine links below."
    report += "\n\nSearch links:\n" + "\n".join(f"{x['site']}: {x['url']}" for x in search_links)
    return {"type": "phone", "target": phone, "geo": geo, "reputation": [], "dorks": cards, "search_links": search_links, "nodes": nodes, "links": links, "cards": cards, "txt_report": report}

def _read_history():
    try:
        with open(HISTORY_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except (OSError, json.JSONDecodeError):
        return []

def _write_history(items):
    temp_path = HISTORY_FILE + ".tmp"
    with open(temp_path, "w", encoding="utf-8") as f:
        json.dump(items[:MAX_HISTORY_ITEMS], f, ensure_ascii=False, indent=2)
    os.replace(temp_path, HISTORY_FILE)

def _save_history(scan_data):
    now = datetime.now().astimezone().isoformat(timespec="seconds")
    cards = scan_data.get("cards", []) or []
    summary = {
        "id": uuid.uuid4().hex,
        "created_at": now,
        "type": scan_data.get("type", "unknown"),
        "target": str(scan_data.get("target", ""))[:200],
        "found": sum(1 for c in cards if c.get("status") is True),
        "not_found": sum(1 for c in cards if c.get("status") is False),
        "unknown": sum(1 for c in cards if c.get("status") is None),
        "data": scan_data,
    }
    items = _read_history()
    items.insert(0, summary)
    _write_history(items)
    return summary

@app.route("/api/history", methods=["GET", "DELETE"])
def api_history():
    if request.method == "DELETE":
        try:
            _write_history([])
            return jsonify({"ok": True, "message": "История очищена"})
        except OSError:
            return jsonify({"error": "Не удалось очистить историю"}), 500
    items = _read_history()
    return jsonify([{k: v for k, v in item.items() if k != "data"} for item in items])

@app.route("/api/history/<record_id>", methods=["GET", "DELETE"])
def api_history_record(record_id):
    items = _read_history()
    item = next((x for x in items if x.get("id") == record_id), None)
    if request.method == "DELETE":
        new_items = [x for x in items if x.get("id") != record_id]
        _write_history(new_items)
        return jsonify({"ok": True}) if item else (jsonify({"error": "Запись не найдена"}), 404)
    if not item:
        return jsonify({"error": "Запись не найдена"}), 404
    return jsonify(item.get("data", {}))

@app.route("/api/intel", methods=["POST"])
def api_intel():
    req = request.get_json(silent=True) or {}
    kind = str(req.get("kind", "")).lower().strip()
    value = str(req.get("value", "")).strip()
    if not value or len(value) > 2048:
        return jsonify({"error": "Введите домен, IP-адрес или URL (до 2048 символов)."}), 400
    if not VT_API_KEY or VT_API_KEY == "PASTE_VIRUSTOTAL_API_KEY_HERE":
        return jsonify({"error": "Не задан API-ключ VirusTotal. Укажи VT_API_KEY в начале main.py или переменную VIRUSTOTAL_API_KEY."}), 400

    if kind == "ip":
        try:
            value = str(ipaddress.ip_address(value))
        except ValueError:
            return jsonify({"error": "Некорректный IP-адрес."}), 400
        endpoint = f"{VT_BASE_URL}/ip_addresses/{value}"
        report_url = f"https://www.virustotal.com/gui/ip-address/{value}"
    elif kind == "domain":
        value = value.lower().rstrip(".")
        if len(value) > 253 or not re.fullmatch(r"(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(?:\.(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?))+", value):
            return jsonify({"error": "Некорректный домен. Введи, например, example.com."}), 400
        endpoint = f"{VT_BASE_URL}/domains/{value}"
        report_url = f"https://www.virustotal.com/gui/domain/{value}"
    elif kind == "url":
        parsed = urlsplit(value)
        if parsed.scheme not in ("http", "https") or not parsed.hostname:
            return jsonify({"error": "URL должен начинаться с http:// или https:// и содержать имя хоста."}), 400
        import base64
        url_id = base64.urlsafe_b64encode(value.encode("utf-8")).decode("ascii").rstrip("=")
        endpoint = f"{VT_BASE_URL}/urls/{url_id}"
        report_url = f"https://www.virustotal.com/gui/url/{url_id}"
    else:
        return jsonify({"error": "Тип проверки должен быть domain, ip или url."}), 400

    try:
        response = requests.get(endpoint, headers={"x-apikey": VT_API_KEY, "accept": "application/json", "User-Agent": get_random_agent()}, timeout=15)
        if response.status_code == 404:
            return jsonify({"status": "UNKNOWN", "message": "Отчёт VirusTotal не найден. Это не доказывает, что объект безопасен или не существует.", "value": value, "kind": kind, "report_url": report_url})
        if response.status_code == 401:
            return jsonify({"error": "VirusTotal отклонил API-ключ (401). Проверь ключ."}), 401
        if response.status_code == 403:
            return jsonify({"error": "VirusTotal запретил доступ (403). Проверь права и доступность endpoint для твоего тарифа."}), 403
        if response.status_code == 429:
            return jsonify({"error": "Лимит запросов VirusTotal исчерпан (429). Попробуй позже."}), 429
        response.raise_for_status()
        payload = response.json().get("data", {})
        attrs = payload.get("attributes", {})
        stats = attrs.get("last_analysis_stats", {}) or {}
        result = {
            "status": "FOUND", "kind": kind, "value": value, "report_url": report_url,
            "reputation": attrs.get("reputation"),
            "analysis_stats": {k: stats.get(k, 0) for k in ("malicious", "suspicious", "harmless", "undetected", "timeout")},
            "last_analysis_date": attrs.get("last_analysis_date"),
            "meaning": "Это данные последнего отчёта VirusTotal, а не безусловный вердикт. Отсутствие обнаружений не гарантирует безопасность."
        }
        if result["last_analysis_date"]:
            result["last_analysis_date"] = datetime.fromtimestamp(result["last_analysis_date"]).astimezone().isoformat(timespec="seconds")
        return jsonify(result)
    except requests.Timeout:
        return jsonify({"error": "Истекло время ожидания VirusTotal. Статус неизвестен."}), 504
    except requests.RequestException:
        app.logger.exception("VirusTotal request failed")
        return jsonify({"error": "Ошибка соединения с VirusTotal. Статус неизвестен."}), 502
    except ValueError:
        return jsonify({"error": "VirusTotal вернул некорректный JSON."}), 502

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/scan", methods=["POST"])
def api_scan():
    try:
        req = request.get_json(silent=True) or {}
        scan_type = req.get("type", "user")
        query = str(req.get("query", "")).strip()
        if not query:
            return jsonify({"error": "Введите имя пользователя или номер телефона."}), 400
        if len(query) > 200:
            return jsonify({"error": "Слишком длинный запрос."}), 400
        if scan_type == "phone":
            data = scan_phone_all(query)
        elif scan_type == "user":
            if not re.fullmatch(r"[A-Za-z0-9_.-]{1,39}", query):
                return jsonify({"error": "Имя пользователя может содержать латинские буквы, цифры, точку, _ и -."}), 400
            data = scan_username_all(query)
        else:
            return jsonify({"error": "Неизвестный тип поиска."}), 400
        try:
            _save_history(data)
        except OSError:
            app.logger.exception("Could not save scan history")
        return jsonify(data)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception:
        app.logger.exception("Scan failed")
        return jsonify({"error": "Ошибка поиска на сервере. Проверьте подключение и попробуйте ещё раз."}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)

